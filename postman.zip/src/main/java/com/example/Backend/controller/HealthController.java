
package com.example.Backend.controller;



import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;



/**

 * Health check endpoint for uptime monitoring.

 * Used by cron services to keep Render backend warm.

 */

@RestController

public class HealthController {



    @GetMapping({"/health", "/api/health"})   // ← ADDED /health alias

    public ResponseEntity<String> health() {

        return ResponseEntity.ok("ResumeForge AI backend is running");

    }

}

